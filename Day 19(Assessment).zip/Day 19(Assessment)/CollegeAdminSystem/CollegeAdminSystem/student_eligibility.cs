﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeAdminSystem
{
    public partial class student_eligibility : Form
    {
       
        public student_eligibility()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


               double marks = Convert.ToDouble(textBox2.Text);
                

                if (marks > 65.0 && marks <=100.0)
                {
                    student_registration form = new student_registration(marks);
                    
                    form.Show();
                    Close();
                }
                else
                    MessageBox.Show("Sorry, you are not eligible to apply.");
                Close();
            }
            catch(Exception m)
            {
                MessageBox.Show("Please enter a value");
            }

        }
    }
}
