﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeAdminSystem
{
    public partial class home_form : Form
    {
        public home_form()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            student_eligibility form=new student_eligibility();
            form.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            employee_register form=new employee_register();
            form.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            attendance_check form=new attendance_check();
            form.Show();
        }
    }
}
