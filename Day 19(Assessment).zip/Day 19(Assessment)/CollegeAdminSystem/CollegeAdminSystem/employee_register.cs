﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CollegeAdminSystem
{
    public partial class employee_register : Form
    {
        SqlConnection con;
        SqlDataReader reader;
        SqlCommand cmd;
        public static string SetValueForProfName = "";
        public static string SetValueForProfEmpID = "";
        public employee_register()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            string name = textBox1.Text;
            string desig = comboBox1.Text;
            string dob = textBox2.Text;
            string address = textBox3.Text;
            string phone = textBox4.Text;
            string email = textBox5.Text;
            
            try
            {
                con.Open();
                cmd.CommandText = "insert into employee values('" + name + "','" + desig + "','" + dob + "','" + address + "','" + phone + "','" + email + "')";
                reader = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Employee registered. \nEmployee ID: "+textBox6.Text);
                if (desig == "Professor" || desig == "professor")
                {
                    SetValueForProfName = textBox1.Text;
                    SetValueForProfEmpID = textBox6.Text;

                    prof_entry form = new prof_entry();
                    form.GetProfData(name, Convert.ToInt32(textBox6.Text));
                    form.Show();
                    Close();
                }
                
                
                
            }
            catch (Exception c)
            {
                MessageBox.Show(c.Message);
            }
            
        }

        private void employee_register_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"data source=ABU-TURAB; initial catalog=College-Management; integrated security=true");
            con.Open();
            cmd = new SqlCommand("select * from employee", con);
            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                textBox6.Text = (reader.GetInt32(6) + 1).ToString();
            }
            con.Close();
        }
    }
}
