﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CollegeAdminSystem
{
    public partial class student_registration : Form
    {
        SqlCommand cmd;
        SqlConnection con;
        SqlDataReader reader;

        public student_registration(double mark)
        {
            InitializeComponent();
            textBox7.Text = (mark.ToString()+"%");

        }

        private void student_registration_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"data source=ABU-TURAB; initial catalog=College-Management; integrated security=true");
            con.Open();
            cmd=new SqlCommand("select * from student", con);
            reader=cmd.ExecuteReader();
            while(reader.Read())
            {
                label8.Text=(reader.GetInt32(7)+1).ToString();
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int temp_id = 0;
            string name = textBox1.Text;
            string regDate = textBox2.Text;
            string dob = textBox3.Text;
            string address = textBox4.Text;
            string phone = textBox5.Text;
            string email = textBox6.Text;
            string course = comboBox1.Text;
            try
            {
                //con = new SqlConnection(@"data source=ABU-TURAB; initial catalog=College-Management; integrated security=true");
                con.Open();
                cmd.CommandText = "insert into student values('" + name + "','" + regDate + "','" + dob + "','" + address + "','" + phone + "','" + email + "','" + course + "')";
                reader = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Student registered.");
                Close();
            }
            catch(Exception c)
            {
                MessageBox.Show(c.Message);
            }
        }
    }
}
