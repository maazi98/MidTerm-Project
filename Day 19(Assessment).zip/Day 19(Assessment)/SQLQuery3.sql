insert into Student values('demo','0/0/0','0/0/0','demo add','demo phone','demo mail','demo course')

alter table student drop column stud_id
alter table student alter column stud_id drop primary key
alter table student add constraint stud_id primary key 
ALTER TABLE student ADD stud_id int IDENTITY(100,1) not null
alter table student add constraint stud_id primary key
sp_rename 'student.stud_age', 'stud_dob', 'column'
select * from student
alter table student alter column stud_dob varchar(50) not null
delete from student where stud_id=103
ALTER TABLE employee ADD emp_id int IDENTITY(1000,1) not null
alter table employee drop column emp_id
alter table employee alter column emp_id add primary key
select * from employee
delete from employee where emp_id=1005 and emp_id=1004

insert into employee values('demo','demo desig','0/0/0','demo add','demo phone','demo mail')
ALTER TABLE professor ADD prof_id int IDENTITY(2000,1) not null
alter table professor alter column prof_name varchar(50) not null
alter table professor alter column prof_sessions int not null
alter table professor alter column emp_id int not null
alter table professor alter column prof_course varchar(50) not null
alter table professor drop column prof_faculty
insert into Professor values('demo prof',1000,0,'demo')
select * from professor

insert into courses values(1,'Business Administration',2000,1)
insert into Faculty values(1,'Business & Management')
insert into Faculty values(2,'Engineering')
insert into Faculty values(3,'Arts')








